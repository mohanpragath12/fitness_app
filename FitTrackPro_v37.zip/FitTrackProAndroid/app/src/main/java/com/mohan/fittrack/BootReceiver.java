package com.mohan.fittrack;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context ctx, Intent i) { if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()))ReminderService.scheduleAll(ctx); }
}
