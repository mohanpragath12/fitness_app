package com.mohan.fittrack;
import android.app.*;
import android.content.*;
import android.os.*;
import java.io.*;
import java.net.*;
import java.util.Calendar;

public class ReminderService extends BroadcastReceiver {
    private static final String TG_TOKEN="8370355052:AAG-scM6GNkAiH5WdkfB0kTgfqQKtps2IBU";
    private static final String TG_CHAT_ID="1003795565";
    private static final String CHANNEL_ID="fittrack_reminders";

    @Override public void onReceive(Context context, Intent intent) {
        String type=intent.getStringExtra("type"); if(type==null)type="activity";
        Calendar cal=Calendar.getInstance();
        String message=buildMessage(type,cal);
        if(message!=null){sendTelegram(message);showNotification(context,type,message);}
        scheduleAll(context);
    }

    private String buildMessage(String type,Calendar cal){
        int h=cal.get(Calendar.HOUR_OF_DAY),dow=cal.get(Calendar.DAY_OF_WEEK);
        String[] acts={"Push-ups, Skips, Squats","Walk 10 mins, Push-ups","Squats, Pull-ups, Skips","Brisk walk, Deep breath","Skips, Squats, Pull-ups"};
        switch(type){
            case "activity": if(h>=9&&h<=18)return "FitTrack Hourly Reminder - Hey Mohankumar! Time for your 10-min activity break! - "+acts[h%acts.length]+" - Stay consistent! - FitTrack Pro"; break;
            case "pumpkin": return "FitTrack Reminder - Time to eat Pumpkin Seeds! Rich in zinc, magnesium and protein! - FitTrack Pro";
            case "hairoil": if(dow==1||dow==3||dow==6)return "FitTrack Reminder - Time to Apply Hair Oil! Sun, Tue, Fri routine. - FitTrack Pro"; break;
            case "beetroot": if(dow==2||dow==3||dow==6||dow==7)return "FitTrack Reminder - Time for Beetroot Juice! Mon, Tue, Fri, Sat routine. - FitTrack Pro"; break;
            case "weekly": if(dow==1)return "FitTrack Weekly Report - Open your FitTrack app for your weekly summary! - FitTrack Pro"; break;
        }
        return null;
    }

    private void sendTelegram(final String msg){
        new Thread(()->{try{
            URL url=new URL("https://api.telegram.org/bot"+TG_TOKEN+"/sendMessage");
            HttpURLConnection c=(HttpURLConnection)url.openConnection();
            c.setRequestMethod("POST");c.setRequestProperty("Content-Type","application/json");c.setDoOutput(true);c.setConnectTimeout(10000);c.setReadTimeout(10000);
            String body="{\"chat_id\":\""+TG_CHAT_ID+"\",\"text\":\""+msg.replace("\"","'")+"\"}";
            OutputStream os=c.getOutputStream();os.write(body.getBytes("UTF-8"));os.close();
            c.getResponseCode();c.disconnect();
        }catch(Exception e){e.printStackTrace();}}).start();
    }

    private void showNotification(Context ctx,String type,String msg){
        NotificationManager nm=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null)return;
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"FitTrack Reminders",NotificationManager.IMPORTANCE_HIGH);nm.createNotificationChannel(ch);}
        Intent i=new Intent(ctx,MainActivity.class);i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(ctx,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(ctx,CHANNEL_ID).setContentTitle(getTitle(type)).setContentText(msg.length()>80?msg.substring(0,80)+"...":msg).setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(pi).setAutoCancel(true).build();
        nm.notify((int)System.currentTimeMillis(),n);
    }

    private String getTitle(String t){switch(t){case "pumpkin":return "Time for Pumpkin Seeds!";case "hairoil":return "Hair Oil Reminder";case "beetroot":return "Beetroot Juice Time!";case "weekly":return "FitTrack Weekly Report";default:return "FitTrack - Time to Move!";}}

    public static void scheduleAll(Context ctx){
        AlarmManager am=(AlarmManager)ctx.getSystemService(Context.ALARM_SERVICE);if(am==null)return;
        for(int h=9;h<=18;h++)scheduleAlarm(ctx,am,h,0,"activity",h*100);
        scheduleAlarm(ctx,am,17,0,"pumpkin",2000);
        scheduleAlarm(ctx,am,20,0,"hairoil",3000);
        scheduleAlarm(ctx,am,17,1,"beetroot",4000);
        scheduleAlarm(ctx,am,20,0,"weekly",5000);
    }

    private static void scheduleAlarm(Context ctx,AlarmManager am,int h,int m,String type,int reqCode){
        Intent i=new Intent(ctx,ReminderService.class);i.putExtra("type",type);
        PendingIntent pi=PendingIntent.getBroadcast(ctx,reqCode,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Calendar cal=Calendar.getInstance();cal.set(Calendar.HOUR_OF_DAY,h);cal.set(Calendar.MINUTE,m);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);
        if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_MONTH,1);
        am.setRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
    }
}
