package com.mohan.fittrack;
import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private Handler mainHandler;
    private SharedPreferences prefs;
    private SharedPreferences profilePrefs;
    private StepReceiver stepReceiver;
    private static final String PREFS_NAME = "FitTrackPrefs";
    private static final String PROFILE_PREFS_NAME = "FitTrackProfile";
    private static final String KEY_TODAY_STEPS = "todaySteps";
    private static final int PERM_REQUEST = 100;
    private static final int NOTIF_PERM_REQUEST = 101;

    private class StepReceiver extends BroadcastReceiver {
        @Override public void onReceive(Context context, Intent intent) { pushSteps(intent.getIntExtra("steps",0)); }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) getWindow().setStatusBarColor(Color.parseColor("#1a2e1a"));
        mainHandler = new Handler(Looper.getMainLooper());
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        profilePrefs = getSharedPreferences(PROFILE_PREFS_NAME, Context.MODE_PRIVATE);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true);
        ws.setAllowFileAccessFromFileURLs(true); ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setAllowFileAccess(true); ws.setAllowContentAccess(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT); ws.setDatabaseEnabled(true);
        ws.setBuiltInZoomControls(false); ws.setDisplayZoomControls(false);
        ws.setLoadWithOverviewMode(true); ws.setUseWideViewPort(true);
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) { cb.invoke(origin,true,false); }
            @Override public void onPermissionRequest(PermissionRequest request) { request.grant(request.getResources()); }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pushSteps(prefs.getInt(KEY_TODAY_STEPS, 0));
                pushProfileToJS();
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        requestRequiredPermissions();
        startStepService();
        ReminderService.scheduleAll(this);
    }

    private void requestRequiredPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, PERM_REQUEST);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_PERM_REQUEST);
    }

    private void startStepService() {
        Intent i = new Intent(this, StepService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == PERM_REQUEST && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startStepService();
    }

    private void pushSteps(final int steps) {
        mainHandler.post(() -> { if (webView != null) webView.evaluateJavascript("if(typeof updateStepsFromAndroid==='function')updateStepsFromAndroid("+steps+");", null); });
    }

    private void pushProfileToJS() {
        mainHandler.postDelayed(() -> {
            if (webView == null) return;
            StringBuilder js = new StringBuilder("(function(){try{");
            String[] fields = {"fname","lname","age","height","weight","goal-p","goal-c","goal-f","p-maintain-inp","gs-url","bed-time","wake-time"};
            for (String f : fields) {
                String v = profilePrefs.getString("pf_"+f, "");
                if (!v.isEmpty()) { v = v.replace("'","\\'"); js.append("var e=document.getElementById('").append(f).append("');if(e&&e.value==='')e.value='").append(v).append("';"); }
            }
            String g = profilePrefs.getString("pf_gender","");
            if (!g.isEmpty()) js.append("var gn=document.getElementById('gender');if(gn&&gn.value==='male')gn.value='").append(g).append("';");
            String m = profilePrefs.getString("pf_p-maintain-inp","");
            if (!m.isEmpty()) js.append("if(typeof autoMaintain!=='undefined')autoMaintain=").append(m).append(";var fm=document.getElementById('fp-m');if(fm)fm.textContent='").append(m).append("';");
            js.append("if(typeof updAv==='function')updAv();if(typeof updDash==='function')updDash();}catch(e){}})();");
            webView.evaluateJavascript(js.toString(), null);
        }, 800);
    }

    public class AndroidBridge {
        @JavascriptInterface public void showToast(String msg) { Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show(); }
        @JavascriptInterface public void vibrate() {
            android.os.Vibrator v = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) v.vibrate(android.os.VibrationEffect.createOneShot(300, android.os.VibrationEffect.DEFAULT_AMPLITUDE)); else v.vibrate(300); }
        }
        @JavascriptInterface public int getTodaySteps() { return prefs.getInt(KEY_TODAY_STEPS, 0); }
        @JavascriptInterface public boolean isStepCounterAvailable() { return true; }
        @JavascriptInterface public void resetSteps() { prefs.edit().putInt(KEY_TODAY_STEPS,0).putInt("dayStart",-1).apply(); pushSteps(0); }
        @JavascriptInterface public void saveProfileField(String key, String value) { if (key!=null&&value!=null) profilePrefs.edit().putString("pf_"+key, value).apply(); }
        @JavascriptInterface public String getProfileField(String key) { return profilePrefs.getString("pf_"+key, ""); }
        @JavascriptInterface public void saveAllProfile(String json) {
            try {
                profilePrefs.edit().putString("pf_all_json", json).apply();
                json = json.replace("{","").replace("}","").replace("\"","");
                for (String pair : json.split(",")) { String[] kv = pair.split(":",2); if(kv.length==2) profilePrefs.edit().putString("pf_"+kv[0].trim(), kv[1].trim()).apply(); }
            } catch (Exception e) {}
        }
        @JavascriptInterface public String getAllProfile() { return profilePrefs.getString("pf_all_json","{}"); }
        @JavascriptInterface public boolean hasProfile() { return profilePrefs.contains("pf_fname")||profilePrefs.contains("pf_p-maintain-inp"); }
    }

    @Override protected void onResume() {
        super.onResume(); webView.onResume();
        stepReceiver = new StepReceiver();
        IntentFilter filter = new IntentFilter("com.mohan.fittrack.STEPS_UPDATE");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) registerReceiver(stepReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(stepReceiver, filter);
        mainHandler.postDelayed(() -> { pushSteps(prefs.getInt(KEY_TODAY_STEPS,0)); pushProfileToJS(); }, 600);
    }

    @Override protected void onPause() {
        super.onPause(); webView.onPause();
        try { if (stepReceiver != null) unregisterReceiver(stepReceiver); } catch (Exception e) {}
        if (webView != null) webView.evaluateJavascript("if(typeof savePf==='function')savePf();if(typeof saveDay==='function')saveDay();", null);
    }

    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
