package com.mohan.fittrack;
import android.app.*;
import android.content.*;
import android.hardware.*;
import android.os.*;
import androidx.core.app.NotificationCompat;
import java.text.SimpleDateFormat;
import java.util.*;

public class StepService extends Service implements SensorEventListener {
    private SensorManager sm; private Sensor sc, sd;
    private SharedPreferences prefs;
    private int todaySteps=0, dayStart=-1;
    private String lastDate="";
    private static final String CHANNEL="fittrack_steps";

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("FitTrackPrefs", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL,"Step Tracker",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        startForeground(1001, new NotificationCompat.Builder(this,CHANNEL).setContentTitle("FitTrack Pro").setContentText("Tracking steps...").setSmallIcon(android.R.drawable.ic_menu_compass).setPriority(NotificationCompat.PRIORITY_LOW).build());
        sm = (SensorManager)getSystemService(SENSOR_SERVICE);
        sc = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if(sc==null) sd = sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        loadData();
        if(sc!=null) sm.registerListener(this,sc,SensorManager.SENSOR_DELAY_NORMAL);
        else if(sd!=null) sm.registerListener(this,sd,SensorManager.SENSOR_DELAY_NORMAL);
    }

    private void loadData() {
        String today = new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(new Date());
        lastDate = prefs.getString("lastDate","");
        if(!today.equals(lastDate)){dayStart=-1;todaySteps=0;prefs.edit().putString("lastDate",today).putInt("todaySteps",0).putInt("dayStart",-1).apply();lastDate=today;}
        else{dayStart=prefs.getInt("dayStart",-1);todaySteps=prefs.getInt("todaySteps",0);}
    }

    @Override public void onSensorChanged(SensorEvent e) {
        String today=new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(new Date());
        if(!today.equals(lastDate)){dayStart=-1;todaySteps=0;lastDate=today;prefs.edit().putString("lastDate",today).putInt("todaySteps",0).putInt("dayStart",-1).apply();}
        if(e.sensor.getType()==Sensor.TYPE_STEP_COUNTER){int t=(int)e.values[0];if(dayStart==-1){dayStart=t;prefs.edit().putInt("dayStart",dayStart).apply();}todaySteps=Math.max(0,t-dayStart);}
        else todaySteps++;
        prefs.edit().putInt("todaySteps",todaySteps).apply();
        Intent bc=new Intent("com.mohan.fittrack.STEPS_UPDATE");bc.putExtra("steps",todaySteps);sendBroadcast(bc);
    }
    @Override public void onAccuracyChanged(Sensor s,int a){}
    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){super.onDestroy();if(sm!=null)sm.unregisterListener(this);}
}
