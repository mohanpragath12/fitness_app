package com.mohan.fittrack;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;

public class ReminderService extends BroadcastReceiver {

    private static final String TG_TOKEN = "8370355052:AAG-scM6GNkAiH5WdkfB0kTgfqQKtps2IBU";
    private static final String TG_CHAT_ID = "1003795565";
    private static final String CHANNEL_ID = "fittrack_reminders";

    @Override
    public void onReceive(Context context, Intent intent) {
        String type = intent.getStringExtra("type");
        if (type == null) type = "activity";

        String message = buildMessage(type, Calendar.getInstance());
        if (message != null) {
            sendTelegram(message);
            showNotification(context, type, message);
        }

        // Reschedule next alarm
        scheduleNext(context);
    }

    private String buildMessage(String type, Calendar cal) {
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int dow = cal.get(Calendar.DAY_OF_WEEK); // 1=Sun,2=Mon..7=Sat

        switch (type) {
            case "activity":
                if (hour >= 9 && hour <= 18) {
                    String[] acts = {"Push-ups, Skips, Squats", "Walk 10 mins, Push-ups", "Squats, Pull-ups, Skips", "Brisk walk, Deep breath", "Skips, Squats, Pull-ups"};
                    return "FitTrack Hourly Reminder - Hey Mohankumar! Time for your 10-min activity break! - " + acts[hour % acts.length] + " - Stay consistent! - FitTrack Pro";
                }
                break;
            case "pumpkin":
                return "FitTrack Reminder - Time to eat Pumpkin Seeds! Daily habit: A handful of pumpkin seeds. Rich in zinc, magnesium and protein! - FitTrack Pro";
            case "hairoil":
                // Sun=1, Tue=3, Fri=6
                if (dow == 1 || dow == 3 || dow == 6) {
                    return "FitTrack Reminder - Time to Apply Hair Oil! Hair care routine for today. Sun, Tue, Fri schedule. - FitTrack Pro";
                }
                break;
            case "beetroot":
                // Mon=2, Tue=3, Fri=6, Sat=7
                if (dow == 2 || dow == 3 || dow == 6 || dow == 7) {
                    return "FitTrack Reminder - Time for Beetroot Juice! Drink fresh beetroot juice now. Mon, Tue, Fri, Sat schedule. - FitTrack Pro";
                }
                break;
        }
        return null;
    }

    private void sendTelegram(final String message) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("https://api.telegram.org/bot" + TG_TOKEN + "/sendMessage");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(10000);

                    String body = "{\"chat_id\":\"" + TG_CHAT_ID + "\",\"text\":\"" + message.replace("\"", "'") + "\"}";
                    OutputStream os = conn.getOutputStream();
                    os.write(body.getBytes("UTF-8"));
                    os.close();

                    conn.getResponseCode(); // execute
                    conn.disconnect();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void showNotification(Context context, String type, String message) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        // Create channel for Android 8+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "FitTrack Reminders", NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Activity and health reminders");
            nm.createNotificationChannel(channel);
        }

        // Open app when notification tapped
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String title = getTitle(type);
        String shortMsg = message.length() > 100 ? message.substring(0, 100) + "..." : message;

        Notification notif = new android.app.Notification.Builder(context, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(shortMsg)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build();

        nm.notify((int) System.currentTimeMillis(), notif);
    }

    private String getTitle(String type) {
        switch (type) {
            case "pumpkin": return "Time for Pumpkin Seeds!";
            case "hairoil": return "Hair Oil Reminder";
            case "beetroot": return "Beetroot Juice Time!";
            default: return "FitTrack - Time to Move!";
        }
    }

    // Schedule all alarms
    public static void scheduleAll(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        // 1. Hourly activity reminders 9AM-6PM
        for (int hour = 9; hour <= 18; hour++) {
            scheduleAlarm(context, am, hour, 0, "activity", hour * 100);
        }

        // 2. Pumpkin seeds - every day 5PM
        scheduleAlarm(context, am, 17, 0, "pumpkin", 2000);

        // 3. Hair oil - Sun/Tue/Fri 8PM
        scheduleAlarm(context, am, 20, 0, "hairoil", 3000);

        // 4. Beetroot juice - Mon/Tue/Fri/Sat 5PM
        // Note: same time as pumpkin but different type - use different ID
        scheduleAlarm(context, am, 17, 1, "beetroot", 4000);
    }

    private static void scheduleAlarm(Context context, AlarmManager am,
                                       int hour, int minute, String type, int requestCode) {
        Intent intent = new Intent(context, ReminderService.class);
        intent.putExtra("type", type);

        PendingIntent pi = PendingIntent.getBroadcast(context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        // If time already passed today, schedule for tomorrow
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_MONTH, 1);
        }

        // Use setRepeating for daily repeat
        am.setRepeating(
            AlarmManager.RTC_WAKEUP,
            cal.getTimeInMillis(),
            AlarmManager.INTERVAL_DAY,
            pi
        );
    }

    // Reschedule after reboot
    private void scheduleNext(Context context) {
        scheduleAll(context);
    }
}
