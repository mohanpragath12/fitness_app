package com.mohan.fittrack;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private WebView webView;
    private SensorManager sensorManager;
    private Sensor stepCounterSensor;
    private Sensor stepDetectorSensor;
    private SharedPreferences prefs;
    private Handler mainHandler;

    private int todaySteps = 0;
    private int totalStepsAtDayStart = -1;
    private boolean stepCounterAvailable = false;
    private boolean isSensorRunning = false;
    private String lastTrackedDate = "";

    private static final String PREFS_NAME = "FitTrackPrefs";
    private static final String KEY_DAY_START = "dayStart";
    private static final String KEY_LAST_DATE = "lastDate";
    private static final String KEY_TODAY_STEPS = "todaySteps";
    private static final int PERM_REQUEST = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Fullscreen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.parseColor("#1a2e1a"));
        }

        mainHandler = new Handler(Looper.getMainLooper());
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // Setup WebView
        webView = new WebView(this);
        setContentView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setDatabaseEnabled(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                cb.invoke(origin, true, false);
            }
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.grant(request.getResources());
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pushSteps(todaySteps);
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
        requestStepPermission();
        setupSensors();
    }

    private void requestStepPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                    new String[]{Manifest.permission.ACTIVITY_RECOGNITION},
                    PERM_REQUEST
                );
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == PERM_REQUEST && results.length > 0
                && results[0] == PackageManager.PERMISSION_GRANTED) {
            setupSensors();
        }
    }

    private void setupSensors() {
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            if (stepCounterSensor == null) {
                stepDetectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
            }
            stepCounterAvailable = (stepCounterSensor != null || stepDetectorSensor != null);
            if (stepCounterAvailable) loadStepData();
        }
    }

    private void loadStepData() {
        String today = getDate();
        lastTrackedDate = prefs.getString(KEY_LAST_DATE, "");
        if (!today.equals(lastTrackedDate)) {
            totalStepsAtDayStart = -1;
            todaySteps = 0;
            prefs.edit()
                .putString(KEY_LAST_DATE, today)
                .putInt(KEY_TODAY_STEPS, 0)
                .putInt(KEY_DAY_START, -1)
                .apply();
            lastTrackedDate = today;
        } else {
            totalStepsAtDayStart = prefs.getInt(KEY_DAY_START, -1);
            todaySteps = prefs.getInt(KEY_TODAY_STEPS, 0);
        }
    }

    private void registerSensors() {
        if (sensorManager == null || isSensorRunning) return;
        if (stepCounterSensor != null) {
            sensorManager.registerListener(this, stepCounterSensor, SensorManager.SENSOR_DELAY_NORMAL);
            isSensorRunning = true;
        } else if (stepDetectorSensor != null) {
            sensorManager.registerListener(this, stepDetectorSensor, SensorManager.SENSOR_DELAY_NORMAL);
            isSensorRunning = true;
        }
    }

    private void unregisterSensors() {
        if (sensorManager != null && isSensorRunning) {
            sensorManager.unregisterListener(this);
            isSensorRunning = false;
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        String today = getDate();
        if (!today.equals(lastTrackedDate)) {
            totalStepsAtDayStart = -1;
            todaySteps = 0;
            lastTrackedDate = today;
            prefs.edit()
                .putString(KEY_LAST_DATE, today)
                .putInt(KEY_TODAY_STEPS, 0)
                .putInt(KEY_DAY_START, -1)
                .apply();
        }
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            int total = (int) event.values[0];
            if (totalStepsAtDayStart == -1) {
                totalStepsAtDayStart = total;
                prefs.edit().putInt(KEY_DAY_START, totalStepsAtDayStart).apply();
            }
            todaySteps = Math.max(0, total - totalStepsAtDayStart);
        } else if (event.sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {
            todaySteps++;
        }
        prefs.edit().putInt(KEY_TODAY_STEPS, todaySteps).apply();
        pushSteps(todaySteps);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private void pushSteps(final int steps) {
        mainHandler.post(() -> {
            if (webView != null) {
                webView.evaluateJavascript(
                    "if(typeof updateStepsFromAndroid==='function')updateStepsFromAndroid(" + steps + ");",
                    null
                );
            }
        });
    }

    private String getDate() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }

    // JavaScript Bridge
    public class AndroidBridge {
        @JavascriptInterface
        public void showToast(String msg) {
            Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
        }

        @JavascriptInterface
        public void vibrate() {
            android.os.Vibrator v = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(android.os.VibrationEffect.createOneShot(
                        300, android.os.VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(300);
                }
            }
        }

        @JavascriptInterface
        public int getTodaySteps() { return todaySteps; }

        @JavascriptInterface
        public boolean isStepCounterAvailable() { return stepCounterAvailable; }

        @JavascriptInterface
        public void resetSteps() {
            todaySteps = 0;
            totalStepsAtDayStart = -1;
            prefs.edit()
                .putInt(KEY_TODAY_STEPS, 0)
                .putInt(KEY_DAY_START, -1)
                .apply();
            pushSteps(0);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        loadStepData();
        registerSensors();
        mainHandler.postDelayed(() -> pushSteps(todaySteps), 800);
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterSensors();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
