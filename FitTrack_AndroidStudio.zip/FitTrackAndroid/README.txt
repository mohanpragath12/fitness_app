# FitTrack Pro — Android App Build Instructions

## Quick Build (10 minutes)

### Step 1 — Install Android Studio
Download from: https://developer.android.com/studio
Install and open Android Studio.

### Step 2 — Open this project
1. In Android Studio click "Open"
2. Navigate to this "FitTrackAndroid" folder
3. Click OK — let it sync (takes 2-3 mins first time)

### Step 3 — Build Debug APK (for testing on your phone)
1. Click menu: Build → Build Bundle(s) / APK(s) → Build APK(s)
2. Wait 1-2 minutes
3. Click "locate" in the popup OR find the APK at:
   app/build/outputs/apk/debug/app-debug.apk

### Step 4 — Install on your phone
Option A — USB:
1. Connect phone via USB
2. Enable USB Debugging: Settings → Developer Options → USB Debugging
3. In Android Studio: Run → Run 'app' → select your phone

Option B — Send APK:
1. Copy app-debug.apk to your phone via WhatsApp/Drive/USB
2. Open the file on phone
3. Allow "Install from unknown sources" if prompted
4. Tap Install

## App Details
- Package: com.mohan.fittrack
- Min Android: 5.0 (API 21)
- Target Android: 14 (API 34)
- Version: 1.0

## Features
- Full FitTrack Pro app (Activity, Diet, Water, Sleep, Reminders, Profile)
- Telegram notifications built in
- Works offline
- Hourly activity reminders 9AM-6PM
