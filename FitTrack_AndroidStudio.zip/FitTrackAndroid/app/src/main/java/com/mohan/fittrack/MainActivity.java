package com.mohan.fittrack;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {

    private WebView webView;
    private SensorManager sensorManager;
    private Sensor stepCounterSensor;
    private Sensor stepDetectorSensor;
    private SharedPreferences prefs;
    private Handler mainHandler;

    private int todaySteps = 0;
    private int totalStepsAtDayStart = -1;
    private boolean stepCounterAvailable = false;
    private boolean isSensorRunning = false;
    private String lastTrackedDate = "";

    private static final String PREFS_NAME = "FitTrackPrefs";
    private static final String KEY_DAY_START_STEPS = "dayStartSteps";
    private static final String KEY_LAST_DATE = "lastDate";
    private static final String KEY_TODAY_STEPS = "todaySteps";
    private static final int PERMISSION_REQUEST = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.parseColor("#1a2e1a"));
        }
        mainHandler = new Handler(Looper.getMainLooper());
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setDatabaseEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.grant(request.getResources());
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pushStepsToWeb(todaySteps);
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        requestStepPermission();
        setupStepSensor();
    }

    private void requestStepPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, PERMISSION_REQUEST);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setupStepSensor();
            } else {
                Toast.makeText(this, "Enable Activity Recognition in Settings for step tracking", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void setupStepSensor() {
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            if (stepCounterSensor == null) {
                stepDetectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
            }
            stepCounterAvailable = (stepCounterSensor != null || stepDetectorSensor != null);
            if (stepCounterAvailable) loadSavedStepData();
        }
    }

    private void loadSavedStepData() {
        String today = getTodayDate();
        lastTrackedDate = prefs.getString(KEY_LAST_DATE, "");
        if (!today.equals(lastTrackedDate)) {
            totalStepsAtDayStart = -1;
            todaySteps = 0;
            prefs.edit().putString(KEY_LAST_DATE, today).putInt(KEY_TODAY_STEPS, 0).putInt(KEY_DAY_START_STEPS, -1).apply();
            lastTrackedDate = today;
        } else {
            totalStepsAtDayStart = prefs.getInt(KEY_DAY_START_STEPS, -1);
            todaySteps = prefs.getInt(KEY_TODAY_STEPS, 0);
        }
    }

    private void registerSensors() {
        if (sensorManager == null || isSensorRunning) return;
        if (stepCounterSensor != null) {
            sensorManager.registerListener(this, stepCounterSensor, SensorManager.SENSOR_DELAY_NORMAL);
            isSensorRunning = true;
        } else if (stepDetectorSensor != null) {
            sensorManager.registerListener(this, stepDetectorSensor, SensorManager.SENSOR_DELAY_NORMAL);
            isSensorRunning = true;
        }
    }

    private void unregisterSensors() {
        if (sensorManager != null && isSensorRunning) {
            sensorManager.unregisterListener(this);
            isSensorRunning = false;
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        String today = getTodayDate();
        if (!today.equals(lastTrackedDate)) {
            totalStepsAtDayStart = -1;
            todaySteps = 0;
            lastTrackedDate = today;
            prefs.edit().putString(KEY_LAST_DATE, today).putInt(KEY_TODAY_STEPS, 0).putInt(KEY_DAY_START_STEPS, -1).apply();
        }
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            int total = (int) event.values[0];
            if (totalStepsAtDayStart == -1) {
                totalStepsAtDayStart = total;
                prefs.edit().putInt(KEY_DAY_START_STEPS, totalStepsAtDayStart).apply();
            }
            todaySteps = Math.max(0, total - totalStepsAtDayStart);
        } else if (event.sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {
            todaySteps++;
        }
        prefs.edit().putInt(KEY_TODAY_STEPS, todaySteps).apply();
        pushStepsToWeb(todaySteps);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private void pushStepsToWeb(final int steps) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (webView != null) {
                    webView.evaluateJavascript(
                        "if(typeof updateStepsFromAndroid==='function')updateStepsFromAndroid(" + steps + ");",
                        null
                    );
                }
            }
        });
    }

    private String getTodayDate() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void showToast(String message) {
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
        }
        @JavascriptInterface
        public void vibrate() {
            android.os.Vibrator v = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(android.os.VibrationEffect.createOneShot(300, android.os.VibrationEffect.DEFAULT_AMPLITUDE));
                } else { v.vibrate(300); }
            }
        }
        @JavascriptInterface
        public int getTodaySteps() { return todaySteps; }
        @JavascriptInterface
        public boolean isStepCounterAvailable() { return stepCounterAvailable; }
        @JavascriptInterface
        public void resetSteps() {
            todaySteps = 0; totalStepsAtDayStart = -1;
            prefs.edit().putInt(KEY_TODAY_STEPS, 0).putInt(KEY_DAY_START_STEPS, -1).apply();
            pushStepsToWeb(0);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        loadSavedStepData();
        registerSensors();
        mainHandler.postDelayed(new Runnable() {
            @Override public void run() { pushStepsToWeb(todaySteps); }
        }, 800);
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterSensors();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) { webView.goBack(); } else { super.onBackPressed(); }
    }
}
