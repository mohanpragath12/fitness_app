package com.mohan.fittrack;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class StepService extends Service implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor stepCounterSensor;
    private Sensor stepDetectorSensor;
    private SharedPreferences prefs;

    private int todaySteps = 0;
    private int totalStepsAtDayStart = -1;
    private String lastTrackedDate = "";

    private static final String CHANNEL_ID = "fittrack_steps";
    private static final int NOTIF_ID = 1001;
    private static final String PREFS_NAME = "FitTrackPrefs";
    private static final String KEY_DAY_START = "dayStart";
    private static final String KEY_LAST_DATE = "lastDate";
    private static final String KEY_TODAY_STEPS = "todaySteps";

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification(0));
        setupSensors();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Step Tracker",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Tracks your daily steps");
            channel.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(int steps) {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FitTrack Pro")
            .setContentText("Steps today: " + steps + " / 10,000")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }

    private void updateNotification(int steps) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, buildNotification(steps));
    }

    private void setupSensors() {
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            if (stepCounterSensor == null) {
                stepDetectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
            }
            loadStepData();
            if (stepCounterSensor != null) {
                sensorManager.registerListener(this, stepCounterSensor, SensorManager.SENSOR_DELAY_NORMAL);
            } else if (stepDetectorSensor != null) {
                sensorManager.registerListener(this, stepDetectorSensor, SensorManager.SENSOR_DELAY_NORMAL);
            }
        }
    }

    private void loadStepData() {
        String today = getDate();
        lastTrackedDate = prefs.getString(KEY_LAST_DATE, "");
        if (!today.equals(lastTrackedDate)) {
            totalStepsAtDayStart = -1;
            todaySteps = 0;
            prefs.edit().putString(KEY_LAST_DATE, today).putInt(KEY_TODAY_STEPS, 0).putInt(KEY_DAY_START, -1).apply();
            lastTrackedDate = today;
        } else {
            totalStepsAtDayStart = prefs.getInt(KEY_DAY_START, -1);
            todaySteps = prefs.getInt(KEY_TODAY_STEPS, 0);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        String today = getDate();
        if (!today.equals(lastTrackedDate)) {
            totalStepsAtDayStart = -1; todaySteps = 0; lastTrackedDate = today;
            prefs.edit().putString(KEY_LAST_DATE, today).putInt(KEY_TODAY_STEPS, 0).putInt(KEY_DAY_START, -1).apply();
        }
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            int total = (int) event.values[0];
            if (totalStepsAtDayStart == -1) {
                totalStepsAtDayStart = total;
                prefs.edit().putInt(KEY_DAY_START, totalStepsAtDayStart).apply();
            }
            todaySteps = Math.max(0, total - totalStepsAtDayStart);
        } else if (event.sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {
            todaySteps++;
        }
        prefs.edit().putInt(KEY_TODAY_STEPS, todaySteps).apply();
        updateNotification(todaySteps);

        // Broadcast to MainActivity if it's running
        Intent broadcast = new Intent("com.mohan.fittrack.STEPS_UPDATE");
        broadcast.putExtra("steps", todaySteps);
        sendBroadcast(broadcast);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY; // Restart if killed
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (sensorManager != null) sensorManager.unregisterListener(this);
    }

    private String getDate() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }
}
