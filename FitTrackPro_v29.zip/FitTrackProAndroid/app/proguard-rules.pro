-keep class com.mohan.fittrack.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
